﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Recerptionist
{
    public partial class CheckInForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\User\Desktop\APU\sem2\IOOP\IOOP assgn\Recerptionist\Recerptionist\DB.mdf"";Integrated Security=True");
        public CheckInForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string RoomID = txtRoomID.Text;
            string OccupancyStatus = "Check In";
            string ReservationID = txtReservationID.Text;
            Room obj1 = new Room(OccupancyStatus, ReservationID, "" ,"", RoomID);
            string checkInStatus = obj1.CustomerCheckIn();
            string Price = obj1.ShowPrice();
            string combinedMessage = $"{checkInStatus}\nInitialBill:{Price}";
            MessageBox.Show(combinedMessage, "Check-In and Price Information");

        }
    }
}