﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recerptionist
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer obj1 = new Customer(txtCustomerID.Text, txtFirstName.Text, txtLastName.Text, txtJob.Text, txtICNumber.Text, txtEmail.Text, txtContactNumber.Text, txtResidentialAddress.Text);
            MessageBox.Show(obj1.addCustomer());
        }

        private void txtCustomerID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
