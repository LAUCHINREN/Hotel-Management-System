﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recerptionist
{
    public partial class CheckOutForm : Form
    {
        public CheckOutForm()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            string RoomID = txtRoomID.Text;
            string ReservationID = txtReservationID.Text;
            decimal AdditionalFee;
            if (!decimal.TryParse(txtAdditionalFee.Text, out AdditionalFee))
            {
                MessageBox.Show("Invalid additional fee entered. Please enter a valid number.", "Error");
                return;
            }
            Room obj2 = new Room("", ReservationID, "", "", RoomID);

            string checkOutStatus = obj2.CustomerCheckOut();
            if (checkOutStatus != "CheckOut Successful.")
            {
                MessageBox.Show(checkOutStatus, "Checkout Status");
                return;
            }

            string price = obj2.ShowPrice();

            decimal PriceValue;
            decimal.TryParse(price, out PriceValue);
            decimal finalBill = PriceValue + AdditionalFee;

            string message = $"{checkOutStatus}\nInitial Bill: {price}\nAdditional Value: {AdditionalFee:C}\nFinal Bill: {finalBill:C}";
            MessageBox.Show(message, "Checkout and Final Bill Information");
        }
    }
}
