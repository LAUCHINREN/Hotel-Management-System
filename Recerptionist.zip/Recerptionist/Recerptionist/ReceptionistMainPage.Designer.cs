﻿namespace Recerptionist
{
    partial class ReceptionistMainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cutomerdetailsbutton = new System.Windows.Forms.Button();
            this.roomconditionbutton = new System.Windows.Forms.Button();
            this.reservationbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cutomerdetailsbutton
            // 
            this.cutomerdetailsbutton.Location = new System.Drawing.Point(271, 50);
            this.cutomerdetailsbutton.Name = "cutomerdetailsbutton";
            this.cutomerdetailsbutton.Size = new System.Drawing.Size(240, 71);
            this.cutomerdetailsbutton.TabIndex = 0;
            this.cutomerdetailsbutton.Text = "CuctomerDetails";
            this.cutomerdetailsbutton.UseVisualStyleBackColor = true;
            this.cutomerdetailsbutton.Click += new System.EventHandler(this.cutomerdetailsbutton_Click);
            // 
            // roomconditionbutton
            // 
            this.roomconditionbutton.Location = new System.Drawing.Point(271, 151);
            this.roomconditionbutton.Name = "roomconditionbutton";
            this.roomconditionbutton.Size = new System.Drawing.Size(240, 70);
            this.roomconditionbutton.TabIndex = 1;
            this.roomconditionbutton.Text = "RoomCondition";
            this.roomconditionbutton.UseVisualStyleBackColor = true;
            this.roomconditionbutton.Click += new System.EventHandler(this.roomconditionbutton_Click);
            // 
            // reservationbutton
            // 
            this.reservationbutton.Location = new System.Drawing.Point(271, 250);
            this.reservationbutton.Name = "reservationbutton";
            this.reservationbutton.Size = new System.Drawing.Size(240, 78);
            this.reservationbutton.TabIndex = 2;
            this.reservationbutton.Text = "Reservation";
            this.reservationbutton.UseVisualStyleBackColor = true;
            this.reservationbutton.Click += new System.EventHandler(this.reservationbutton_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(271, 360);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(240, 78);
            this.button1.TabIndex = 3;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ReceptionistMainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.reservationbutton);
            this.Controls.Add(this.roomconditionbutton);
            this.Controls.Add(this.cutomerdetailsbutton);
            this.Name = "ReceptionistMainPage";
            this.Text = "ReceptionistMainPage";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cutomerdetailsbutton;
        private System.Windows.Forms.Button roomconditionbutton;
        private System.Windows.Forms.Button reservationbutton;
        private System.Windows.Forms.Button button1;
    }
}