﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Diagnostics;

namespace Recerptionist
{
    internal class Room
    {
        static SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\User\Desktop\APU\sem2\IOOP\IOOP assgn\Recerptionist\Recerptionist\DB.mdf"";Integrated Security=True");
        private string RoomID;
        private string OccupancyStatus;
        private string ReservationID;
        private string FinalBill;
        private string Price;


        public string OccupancyStatus1 { get => OccupancyStatus; set => OccupancyStatus = value; }
        public string FinalBill1 { get => FinalBill; set => FinalBill = value; }
        public string ReservationID1 { get => ReservationID; set => ReservationID = value; }
        public string Price1 { get => Price; set => Price = value; }
        public string RoomID1 { get => RoomID; set => RoomID = value; }

        public Room(string o, string r, string f, string p, string R)
        {
            OccupancyStatus = o;
            ReservationID = r;
            FinalBill = f;
            Price = p;
            RoomID = R;
        }

        public string CustomerCheckIn()
        {
            string status;
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("UPDATE Room set OccupancyStatus = @status WHERE RoomID = @RoomID", con))
                    {
                        cmd.Parameters.AddWithValue("@RoomID", RoomID);
                        cmd.Parameters.AddWithValue("@status", OccupancyStatus);


                        int i = cmd.ExecuteNonQuery();
                        if (i > 0)
                            status = "CheckIn Successful.";
                        else
                            status = "Unable to CheckIn.";
                    }
                }
                catch (Exception ex)
                {
                    status = "Error: " + ex.Message;
                }
                finally
                {
                    con.Close();
                }
            }
            return status;
        }

        public string CustomerCheckOut()
        {
            string status;
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT OccupancyStatus FROM Room WHERE RoomID = @RoomID", con))
                    {
                        cmd.Parameters.AddWithValue("@RoomID", RoomID);

                        object result = cmd.ExecuteScalar();

                        if (result == null)
                        {
                            status = "RoomID not found.";
                        }
                        else if (result.ToString() != "Check In")
                        {
                            status = "Room is not currently checked in.";
                        }
                        else
                        {
                            string updateStatusQuery = "UPDATE Room SET OccupancyStatus = 'Checked Out' WHERE RoomID = @RoomID";
                            using (SqlCommand updateCmd = new SqlCommand(updateStatusQuery, con))
                            {
                                updateCmd.Parameters.AddWithValue("@RoomID", RoomID);

                                int i = updateCmd.ExecuteNonQuery();
                                if (i > 0)
                                    status = "CheckOut Successful.";
                                else
                                    status = "Unable to CheckOut.";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    status = "Error: " + ex.Message;
                }
                finally
                {
                    con.Close();
                }
            }
            return status;
        }

            public string ShowPrice()
            {
                string Price = "";

                {
                    try
                    {
                        con.Open();
                        string query = "SELECT Price FROM Reservation WHERE ReservationID = @reservationid";

                        using (SqlCommand cmd = new SqlCommand(query, con))
                        {
                            cmd.Parameters.AddWithValue("@reservationid", ReservationID);
                            object result = cmd.ExecuteScalar();

                            if (result != null)
                            {
                                Price = result.ToString();
                            }
                            else
                            {
                                Price = "No data found for the specified ReservationID.";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                    finally 
                    { 
                        con.Close(); 
                    }
                }
                return Price;
            }
    }
}
