﻿namespace Recerptionist
{
    partial class RoomCondition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.field = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.roomIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bedsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bathroomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bathroomTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amentitiesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricePerNightDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.occupancyStatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roomBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBDataSet2 = new Recerptionist.DBDataSet2();
            this.roomTableAdapter = new Recerptionist.DBDataSet2TableAdapters.RoomTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtValue);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.field);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(554, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SearchBar";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(391, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 55);
            this.button1.TabIndex = 2;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(145, 79);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(154, 22);
            this.txtValue.TabIndex = 2;
            this.txtValue.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Value:";
            // 
            // field
            // 
            this.field.FormattingEnabled = true;
            this.field.Items.AddRange(new object[] {
            "RoomID",
            "Location",
            "RoomType",
            "Guest",
            "Beds",
            "Bathroom",
            "BathroomType",
            "Amentities",
            "PricePerNight",
            "OccupancyStatus"});
            this.field.Location = new System.Drawing.Point(145, 29);
            this.field.Name = "field";
            this.field.Size = new System.Drawing.Size(154, 24);
            this.field.TabIndex = 1;
            this.field.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "InfoFilter:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.roomIDDataGridViewTextBoxColumn,
            this.locationDataGridViewTextBoxColumn,
            this.roomTypeDataGridViewTextBoxColumn,
            this.guestDataGridViewTextBoxColumn,
            this.bedsDataGridViewTextBoxColumn,
            this.bathroomDataGridViewTextBoxColumn,
            this.bathroomTypeDataGridViewTextBoxColumn,
            this.amentitiesDataGridViewTextBoxColumn,
            this.pricePerNightDataGridViewTextBoxColumn,
            this.occupancyStatusDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.roomBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 156);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1310, 298);
            this.dataGridView1.TabIndex = 1;
            // 
            // roomIDDataGridViewTextBoxColumn
            // 
            this.roomIDDataGridViewTextBoxColumn.DataPropertyName = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.HeaderText = "RoomID";
            this.roomIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roomIDDataGridViewTextBoxColumn.Name = "roomIDDataGridViewTextBoxColumn";
            this.roomIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // locationDataGridViewTextBoxColumn
            // 
            this.locationDataGridViewTextBoxColumn.DataPropertyName = "Location";
            this.locationDataGridViewTextBoxColumn.HeaderText = "Location";
            this.locationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.locationDataGridViewTextBoxColumn.Name = "locationDataGridViewTextBoxColumn";
            this.locationDataGridViewTextBoxColumn.Width = 125;
            // 
            // roomTypeDataGridViewTextBoxColumn
            // 
            this.roomTypeDataGridViewTextBoxColumn.DataPropertyName = "RoomType";
            this.roomTypeDataGridViewTextBoxColumn.HeaderText = "RoomType";
            this.roomTypeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.roomTypeDataGridViewTextBoxColumn.Name = "roomTypeDataGridViewTextBoxColumn";
            this.roomTypeDataGridViewTextBoxColumn.Width = 125;
            // 
            // guestDataGridViewTextBoxColumn
            // 
            this.guestDataGridViewTextBoxColumn.DataPropertyName = "Guest";
            this.guestDataGridViewTextBoxColumn.HeaderText = "Guest";
            this.guestDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.guestDataGridViewTextBoxColumn.Name = "guestDataGridViewTextBoxColumn";
            this.guestDataGridViewTextBoxColumn.Width = 125;
            // 
            // bedsDataGridViewTextBoxColumn
            // 
            this.bedsDataGridViewTextBoxColumn.DataPropertyName = "Beds";
            this.bedsDataGridViewTextBoxColumn.HeaderText = "Beds";
            this.bedsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bedsDataGridViewTextBoxColumn.Name = "bedsDataGridViewTextBoxColumn";
            this.bedsDataGridViewTextBoxColumn.Width = 125;
            // 
            // bathroomDataGridViewTextBoxColumn
            // 
            this.bathroomDataGridViewTextBoxColumn.DataPropertyName = "Bathroom";
            this.bathroomDataGridViewTextBoxColumn.HeaderText = "Bathroom";
            this.bathroomDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bathroomDataGridViewTextBoxColumn.Name = "bathroomDataGridViewTextBoxColumn";
            this.bathroomDataGridViewTextBoxColumn.Width = 125;
            // 
            // bathroomTypeDataGridViewTextBoxColumn
            // 
            this.bathroomTypeDataGridViewTextBoxColumn.DataPropertyName = "BathroomType";
            this.bathroomTypeDataGridViewTextBoxColumn.HeaderText = "BathroomType";
            this.bathroomTypeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bathroomTypeDataGridViewTextBoxColumn.Name = "bathroomTypeDataGridViewTextBoxColumn";
            this.bathroomTypeDataGridViewTextBoxColumn.Width = 125;
            // 
            // amentitiesDataGridViewTextBoxColumn
            // 
            this.amentitiesDataGridViewTextBoxColumn.DataPropertyName = "Amentities";
            this.amentitiesDataGridViewTextBoxColumn.HeaderText = "Amentities";
            this.amentitiesDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.amentitiesDataGridViewTextBoxColumn.Name = "amentitiesDataGridViewTextBoxColumn";
            this.amentitiesDataGridViewTextBoxColumn.Width = 125;
            // 
            // pricePerNightDataGridViewTextBoxColumn
            // 
            this.pricePerNightDataGridViewTextBoxColumn.DataPropertyName = "PricePerNight";
            this.pricePerNightDataGridViewTextBoxColumn.HeaderText = "PricePerNight";
            this.pricePerNightDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pricePerNightDataGridViewTextBoxColumn.Name = "pricePerNightDataGridViewTextBoxColumn";
            this.pricePerNightDataGridViewTextBoxColumn.Width = 125;
            // 
            // occupancyStatusDataGridViewTextBoxColumn
            // 
            this.occupancyStatusDataGridViewTextBoxColumn.DataPropertyName = "OccupancyStatus";
            this.occupancyStatusDataGridViewTextBoxColumn.HeaderText = "OccupancyStatus";
            this.occupancyStatusDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.occupancyStatusDataGridViewTextBoxColumn.Name = "occupancyStatusDataGridViewTextBoxColumn";
            this.occupancyStatusDataGridViewTextBoxColumn.Width = 125;
            // 
            // roomBindingSource
            // 
            this.roomBindingSource.DataMember = "Room";
            this.roomBindingSource.DataSource = this.dBDataSet2;
            // 
            // dBDataSet2
            // 
            this.dBDataSet2.DataSetName = "DBDataSet2";
            this.dBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // roomTableAdapter
            // 
            this.roomTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(922, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(122, 39);
            this.button2.TabIndex = 2;
            this.button2.Text = "CheckIn";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(922, 90);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 36);
            this.button3.TabIndex = 3;
            this.button3.Text = "CheckOut";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // RoomCondition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1334, 466);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "RoomCondition";
            this.Text = "CheckInOut";
            this.Load += new System.EventHandler(this.RoomCondition_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBDataSet2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox field;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DBDataSet2 dBDataSet2;
        private System.Windows.Forms.BindingSource roomBindingSource;
        private DBDataSet2TableAdapters.RoomTableAdapter roomTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn guestDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bedsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bathroomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bathroomTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amentitiesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricePerNightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn occupancyStatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}