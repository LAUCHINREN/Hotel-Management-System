﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recerptionist
{
    public partial class RoomCondition : Form
    {
        static SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\User\Desktop\APU\sem2\IOOP\IOOP assgn\Recerptionist\Recerptionist\DB.mdf"";Integrated Security=True");

        public RoomCondition()
        {
            InitializeComponent();
        }

        private void RoomCondition_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBDataSet2.Room' table. You can move, or remove it, as needed.
            this.roomTableAdapter.Fill(this.dBDataSet2.Room);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (field.Text == "RoomID")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where RoomID = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "Location")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where Location = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "RoomType")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where RoomType = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "Guest")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where Guests = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "Beds")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where Beds = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "Bathroom")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where Bathroom = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "BathroomType")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where BathroomType = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "Amentities")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where Amentities = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (field.Text == "PricePerNight")
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where PricePerNight = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT RoomID, Location, RoomType, Guest, Beds, Bathroom, BathroomType, Amentities, PricePerNight, OccupancyStatus FROM Room where OccupancyStatus = '" + txtValue.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Grid();
        }

        public void Grid()
        {
            con.Open();
            string query = "select * from Room";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CheckInForm f3 = new CheckInForm();
            f3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CheckOutForm f4 = new CheckOutForm();
            f4.Show();
        }
    }
}
